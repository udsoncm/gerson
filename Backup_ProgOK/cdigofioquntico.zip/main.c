#include <stdio.h>
#include <stdlib.h>
#include <math.h>
#include <lapacke.h>

int periodic(int N, double *diag, double *evals, double *evecs) {
  int i;
  for (i=0; i<N*N; i++)
    evecs[i] = 0.0;
  for (i=0; i<N; i++)
    evecs[i*N+i] = diag[i];
  for (i=0; i<N-1; i++)
    evecs[i*N+i+1] = -1.0;
  evecs[0*N+N-1] = -1.0;

  LAPACKE_dsyev(LAPACK_COL_MAJOR, 'V', 'L', N, evecs, N, evals);

  return(0);
}

int hardwall(int N, double *diag, double *subd, double *evals, double *evecs, int *ifail) {
  int Nf;
  int Nemin = 1, Nemax = N;
  double Emin = 0.0, Emax = 0.0;
  double abstol = 1E-4;

  LAPACKE_dstevx(LAPACK_COL_MAJOR, 'V', 'A', N, diag, subd, Emin, Emax, Nemin, Nemax, abstol, &Nf, evals, evecs, N, ifail);

  return(0);
}



int main() {
  int i;
  int N = 1000; // number of points
  double dx = 1.0; // nm
  // x = -L/2 + i*dx
  double L = (N-1)*dx, x; // nm
  double V0 = 50.0; // meV
  double wx = L/10.0; // nm
  double meff = 0.067; // GaAs
  double Ry = 13.6056917253e3; // meV
  double a0 = 0.0529177208319; // nm
  double h2m = 2.0*Ry*a0*a0/meff/2.0; // h^2/2m [meV nm^2] => Ry = hbar^2/2/m/a0^2
  double Eunit = h2m/dx/dx;
  double *v = (double *) calloc(N, sizeof(double));
  FILE *fp = fopen("ldos.dat", "w");


  // LAPACK
  double *diag = (double *) calloc(N, sizeof(double));
  double *subd = (double *) calloc(N-1, sizeof(double));
  double *evals = (double *) calloc(N, sizeof(double));
  double *evecs = (double *) calloc(N*N, sizeof(double));
  int *ifail = (int *) calloc(N, sizeof(int));
  // ==============

  
  for (i=0; i<N; i++) {
    x = -L/2.0 + i*dx;
    v[i] = V0*exp(-pow(x/wx, 2.0)/2.0); // gaussian barrier
    diag[i] = 2.0 + v[i]/Eunit;
  }
  for (i=0; i<N-1; i++)
    subd[i] = -1.0;

  //hardwall(N, diag, subd, evals, evecs, ifail);
  periodic(N, diag, evals, evecs);

  //for (i=0; i<N; i++) fprintf(fp, "%g\n", evals[i]*Eunit);

  // LDOS(E) = sum_{i~E} |psi(x)|^2
  // file cols: x E LDOS
  int step, steps = 1000;
  double Emin = evals[0], Emax = evals[N-1];
  double Ei, dE = (Emax-Emin)/steps;
  double *LDOS = (double *) calloc(N, sizeof(double));
  int j;
  
  for (i=0, step=0; step<steps; step++) {
    // step*dE < E < (step+1)*dE
    for (j=0; j<N; j++)
      LDOS[j] = 0.0;
    while (evals[i] < (step+1)*dE) {
      for (j=0; j<N; j++)
	LDOS[j] += pow(evecs[i*N+j], 2.0);
      i++;
    } // while
    for (j=0; j<N; j++) {
      x = -L/2.0 + j*dx;
      fprintf(fp, "%g %g %g\n", x, (step+0.5)*dE*Eunit, LDOS[j]);
    } // for j
    fprintf(fp, "\n");
  } // for i


  fclose(fp);
  free(v);
  free(diag);
  free(subd);
  free(evals);
  free(evecs);
  free(ifail);
  return(0);
}
